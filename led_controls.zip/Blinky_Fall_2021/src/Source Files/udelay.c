#include "em_device.h"
#include "em_cmu.h"
#include "em_core.h"
#if defined( RTCC_PRESENT ) && ( RTCC_COUNT == 1 )
#include "em_rtcc.h"
#else
#include "em_rtc.h"
#endif

#include "udelay.h"
volatile unsigned long loops_per_jiffy = (1<<12);

#if defined(__GNUC__) /* GCC */
/***************************************************************************/
void UDELAY_Delay( uint32_t usecs )
{

  while(1) {
      GPIO->P[gpioPortC].DOUT = 0xFFFF;
//  __ASM volatile (
//#if ( __CORTEX_M == 0x00 )
//"        .syntax unified           \n"
//"        .arch armv6-m             \n"
//#endif
//"        nop                       \n"
//"        nop                       \n"
//"        nop                       \n"
//"        nop                       \n"
//"        nop                       \n"
//"        nop                       \n"
//#if ( __CORTEX_M == 0x00 )
//"2:                                \n"
//"        .syntax divided           \n" : : "r" (usecs), "r" (&loops_per_jiffy) : "r0", "r2", "cc" );
//#else
//"2:                                \n" : : "r" (usecs), "r" (&loops_per_jiffy) : "r0", "r2", "cc" );
//#endif
    for(uint32_t i = 0; i < 150; i++);
    GPIO->P[gpioPortC].DOUT = 0x0000;
//    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time = 0;
  }
}

void all_on(uint32_t num_bits)
{

  while(1) {
        GPIO->P[gpioPortC].DOUT = 0xFFFF;
        num_bits--;
        if(num_bits == 0) {
            break;
        }

        GPIO->P[gpioPortC].DOUT = 0x0000;
        uint32_t declared_to_add_time = 0;
    }
}



void all_off(uint32_t num_bits)
{

  while(1) {
        GPIO->P[gpioPortC].DOUT = 0x0000;
        num_bits--;
        if(num_bits == 0) {
            break;
        }

        GPIO->P[gpioPortC].DOUT = 0xFFFF;
        uint32_t declared_to_add_time = 0;
    }
}

// trying to turn the first LED green (need first 8 bits high the rest low)
void all_green(uint32_t num_bits) {

  while(1) {
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits--;
    if(num_bits == 0) {
        break;
    }

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time0 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time1 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time2 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time3 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time4 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time5 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time6 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time7 = 0;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time8 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time9 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time10 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time11 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time12 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time13 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time14 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time15 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time16 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time17 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time18 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time19 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time20 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time21 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time22 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time23 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
  }
}

// trying to turn the first LED green (need first 8 bits high the rest low)
void all_red(uint32_t num_bits) {

  while(1) {
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time8 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits--;
    if(num_bits == 0) {
        break;
    }
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time9 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time10 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time11 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time12 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time13 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time14 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time15 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time0 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time1 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time2 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time3 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time4 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time5 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time6 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time7 = 0;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time16 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time17 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time18 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time19 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time20 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time21 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time22 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time23 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
  }
}

// trying to turn the first LED green (need first 8 bits high the rest low)
void all_blue(uint32_t num_bits) {

  while(1) {
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time8 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits--;
    if(num_bits == 0) {
        break;
    }
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time9 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time10 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time11 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time12 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time13 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time14 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time15 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time16 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time17 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time18 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time19 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time20 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time21 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time22 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 0 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    uint32_t declared_to_add_time23 = 0;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    num_bits++;
    num_bits--;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time0 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time1 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time2 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time3 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time4 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time5 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time6 = 0;
    // -------------------------------------
    // ---------- Sends a 1 ----------------
    GPIO->P[gpioPortC].DOUT = 0xFFFF;
    num_bits++;
    num_bits--;

    GPIO->P[gpioPortC].DOUT = 0x0000;
    uint32_t declared_to_add_time7 = 0;
    // -------------------------------------
  }
}

#endif /* defined(__GNUC__) */
