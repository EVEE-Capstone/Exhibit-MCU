/**************************************************************************/
#ifndef __UDELAY_H
#define __UDELAY_H
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

//void UDELAY_Calibrate(void);
void UDELAY_Delay(uint32_t usecs);
void all_off(uint32_t usecs);
void all_on(uint32_t usecs);
void all_green(uint32_t num_bits);
void all_red(uint32_t num_bits);
void all_blue(uint32_t num_bits);

#ifdef __cplusplus
}
#endif

#endif
